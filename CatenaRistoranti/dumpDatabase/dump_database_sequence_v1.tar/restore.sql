--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: db_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.db_sequence
    START WITH 10
    INCREMENT BY 1
    MINVALUE 10
    NO MAXVALUE
    CACHE 1;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: piatto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.piatto (
    id bigint NOT NULL,
    nome character varying NOT NULL
);


--
-- Name: recensione; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recensione (
    id bigint NOT NULL,
    titolo character varying NOT NULL,
    testo character varying NOT NULL,
    numero_mi_piace integer NOT NULL,
    numero_non_mi_piace integer,
    ristorante bigint NOT NULL,
    scritta_da character varying NOT NULL
);


--
-- Name: ristorante; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ristorante (
    id bigint NOT NULL,
    nome character varying NOT NULL,
    cap_ubicazione character varying
);


--
-- Name: serve; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.serve (
    id bigint NOT NULL,
    piatto bigint NOT NULL,
    ristorante bigint NOT NULL
);


--
-- Name: utente; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.utente (
    username character varying NOT NULL,
    password character varying NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    data_nascita date NOT NULL,
    ruolo character varying NOT NULL
);


--
-- Data for Name: piatto; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3280.dat

--
-- Data for Name: recensione; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3281.dat

--
-- Data for Name: ristorante; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3282.dat

--
-- Data for Name: serve; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3284.dat

--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3283.dat

--
-- Name: db_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.db_sequence', 10, true);


--
-- Name: piatto piatto_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.piatto
    ADD CONSTRAINT piatto_pk PRIMARY KEY (id);


--
-- Name: recensione recensione_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_pk PRIMARY KEY (id);


--
-- Name: ristorante ristorante_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ristorante
    ADD CONSTRAINT ristorante_pk PRIMARY KEY (id);


--
-- Name: serve serve_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.serve
    ADD CONSTRAINT serve_pk PRIMARY KEY (id);


--
-- Name: utente utente_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_pk PRIMARY KEY (username);


--
-- Name: recensione recensione_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_fk FOREIGN KEY (ristorante) REFERENCES public.ristorante(id);


--
-- Name: recensione recensione_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_fk_1 FOREIGN KEY (scritta_da) REFERENCES public.utente(username);


--
-- Name: serve serve_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.serve
    ADD CONSTRAINT serve_fk FOREIGN KEY (ristorante) REFERENCES public.ristorante(id);


--
-- Name: serve serve_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.serve
    ADD CONSTRAINT serve_fk_1 FOREIGN KEY (piatto) REFERENCES public.piatto(id);


--
-- PostgreSQL database dump complete
--

