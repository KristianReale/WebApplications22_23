--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Italian_Italy.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: db_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.db_sequence
    START WITH 10
    INCREMENT BY 1
    MINVALUE 10
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_sequence OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: piatto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.piatto (
    id bigint NOT NULL,
    nome character varying NOT NULL
);


ALTER TABLE public.piatto OWNER TO postgres;

--
-- Name: recensione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensione (
    id bigint NOT NULL,
    titolo character varying NOT NULL,
    testo character varying NOT NULL,
    numero_mi_piace integer NOT NULL,
    numero_non_mi_piace integer,
    ristorante bigint,
    scritta_da character varying
);


ALTER TABLE public.recensione OWNER TO postgres;

--
-- Name: ristorante; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ristorante (
    id bigint NOT NULL,
    nome character varying NOT NULL,
    cap_ubicazione character varying
);


ALTER TABLE public.ristorante OWNER TO postgres;

--
-- Name: seq_generale; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.seq_generale
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq_generale OWNER TO postgres;

--
-- Name: serve; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.serve (
    id bigint NOT NULL,
    piatto bigint,
    ristorante bigint
);


ALTER TABLE public.serve OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utente (
    username character varying NOT NULL,
    password character varying NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    data_nascita date NOT NULL,
    ruolo character varying NOT NULL
);


ALTER TABLE public.utente OWNER TO postgres;

--
-- Data for Name: piatto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.piatto (id, nome) FROM stdin;
\.
COPY public.piatto (id, nome) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: recensione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensione (id, titolo, testo, numero_mi_piace, numero_non_mi_piace, ristorante, scritta_da) FROM stdin;
\.
COPY public.recensione (id, titolo, testo, numero_mi_piace, numero_non_mi_piace, ristorante, scritta_da) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: ristorante; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ristorante (id, nome, cap_ubicazione) FROM stdin;
\.
COPY public.ristorante (id, nome, cap_ubicazione) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: serve; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.serve (id, piatto, ristorante) FROM stdin;
\.
COPY public.serve (id, piatto, ristorante) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utente (username, password, nome, cognome, data_nascita, ruolo) FROM stdin;
\.
COPY public.utente (username, password, nome, cognome, data_nascita, ruolo) FROM '$$PATH$$/3341.dat';

--
-- Name: db_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.db_sequence', 15, true);


--
-- Name: seq_generale; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.seq_generale', 2, true);


--
-- Name: piatto piatto_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.piatto
    ADD CONSTRAINT piatto_pk PRIMARY KEY (id);


--
-- Name: recensione recensione_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_pk PRIMARY KEY (id);


--
-- Name: ristorante ristorante_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ristorante
    ADD CONSTRAINT ristorante_pk PRIMARY KEY (id);


--
-- Name: serve serve_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serve
    ADD CONSTRAINT serve_pk PRIMARY KEY (id);


--
-- Name: utente utente_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_pk PRIMARY KEY (username);


--
-- Name: recensione recensione_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_fk FOREIGN KEY (ristorante) REFERENCES public.ristorante(id) ON DELETE SET NULL;


--
-- Name: recensione recensione_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_fk_1 FOREIGN KEY (scritta_da) REFERENCES public.utente(username) ON DELETE SET NULL;


--
-- Name: serve serve_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serve
    ADD CONSTRAINT serve_fk FOREIGN KEY (ristorante) REFERENCES public.ristorante(id) ON DELETE SET NULL;


--
-- Name: serve serve_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serve
    ADD CONSTRAINT serve_fk_1 FOREIGN KEY (piatto) REFERENCES public.piatto(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

